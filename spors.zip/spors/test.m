clear all

% for a=1:6
% i=randi([1,5]);
% name=[num2str(i) '.jpg'];
% I=imread(name);
% if a==1
%    I_n=I;
% else
%     I_n=[I_n I];
% end
% end

i=randi([1,5]);
Im1=imread('Tubaria-furfuracea-2016-05-26-spore-100-325.jpg');
Im1=rgb2gray(Im1);
Im1=max(Im1(:))-Im1;
bw=Im1>50 ; 
S1 = bwconncomp(bw);

Smin=500;
st=0;
for j=1:S1.NumObjects
    if length(S1.PixelIdxList{j}) > Smin
        
    st=st+1;    
    Im = zeros(S1.ImageSize);
    Im(S1.PixelIdxList{j}) = 255;
    
    Im=medfilt2(Im, [20,20],'symmetric');
    S2=bwconncomp(Im);
    cent=struct2cell(regionprops(S2,'centroid'));
    G = ceil(cent{1});
    x = G(2); y = G(1);
    if Im(G(2),G(1))>0
     
    Im = edge(Im,'Canny');
    S2=bwconncomp(Im);
    
   
    [~,Max_L]=max(length(S2.PixelIdxList));
    S2.PixelIdxList
    Im = zeros(S2.ImageSize);
    Im(S2.PixelIdxList{Max_L}) = 255;
    
    S2=bwconncomp(Im);
    B=regionprops(S2,'BoundingBox');
    Im= imcrop(Im,[B.BoundingBox(1) B.BoundingBox(2)...
    B.BoundingBox(3) B.BoundingBox(4)]);
    
    [Im] = Zaliv(Im);
    [R,L]=size(Im);
    I_z=zeros(R,6);
    Im=[I_z Im I_z];
    I_z=zeros(6,L+12);
    Im=[I_z; Im; I_z];
    
    
    angle=0:1:360;
    N=length(angle);
for a = 1:N
I=imrotate(Im,angle(a));
I=I>0;
Ss = bwconncomp(I);
I2 = zeros(Ss.ImageSize);
s1 = regionprops(Ss,'centroid');
g1=0;
g1 = ceil(s1.Centroid);
cort=g1(1);

while I(g1(2),cort)~=0
    cort=cort+1;
end
I2(g1(2),cort)= 2;
I=I+I2;
distanse=g1(1):cort;
L(a)=length(distanse);
for i=1:L(a)
    I(g1(2),distanse(i))=3;
end
% figure (1)
% imagesc(I);
end

[p,s]=max(L);

Dmin=L(1:s-1); Dmax=L(s:361);

L=[Dmax Dmin]/p;

LL=L;
 for i = 2:1:length(L)-2
     LL(i)=(L(i)+L(i-1)+L(i+1))./3;
 end
 
 if st==1
        S_c=LL;
 else
        S_c=[S_c;LL];
    end
    end
    end
    clc
end