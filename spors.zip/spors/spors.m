clear all
close all

T1=5; T2=8;

I1=imread('Agaricus-bisporus-2016-05-09-spore-100-359.jpg');
[SF1,L1] = SF_rasch1(I1,50);


clear L1
hold on
M1=(SF1(:,T1)); M2=(SF1(:,T2));
plot (M1,M2,'.'); grid on


I2=imread('Entoloma-incanum-2019-08-22-spore-40-1140.jpg');
[SF2,L2] = SF_rasch1(I2,50);

clear L2
M1=(SF2(:,T1)); M2=(SF2(:,T2));
plot (M1,M2,'.');


I3=imread('Lepiota-clypeolaria-2015-08-22-spore-40.jpg');
[SF3,L3] = SF_rasch1(I3,45);

clear  L3
M1=(SF3(:,T1)); M2=(SF3(:,T2));
plot (M1,M2,'.');

I4=imread('Stropharia-caerulea-2016-11-27-spore-100-295.jpg');
[SF4,L4] = SF_rasch1(I4,50);

clear  L4
M1=(SF4(:,T1)); M2=(SF4(:,T2));
plot (M1,M2,'.');

I5=imread('Tubaria-furfuracea-2016-05-26-spore-100-325.jpg');
[SF5,L5] = SF_rasch1(I5,45);

clear L5
M1=(SF5(:,T1)); M2=(SF5(:,T2));
plot (M1,M2,'.');

