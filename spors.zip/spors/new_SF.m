function [S_c] = new_SF(I1,T)

Im1=rgb2gray(I1);
Im1=max(Im1(:))-Im1;
bw=Im1>T;
bw = bwareaopen(bw,30);
imshow(bw);
S = bwconncomp(bw);

for i=1:S.NumObjects
    tic
    I = zeros(S.ImageSize);
    I(S.PixelIdxList{i}) = 255;
    if i==1
        [LL] = razvert(I);
        S_c=LL;
    else
       [LL] = razvert(I);
        S_c=[S_c;LL];
    end
     toc 
end

end

