function [SF,L] = SF_rasch(Im,T)
Im=rgb2gray(Im);
Im=max(Im(:))-Im;
bw=Im>T;
bw = bwareaopen(bw,30);
bw = imfill(bw,'holes');
S=bwconncomp(bw);
L=S.NumObjects;
B=struct2cell(regionprops(S,'BoundingBox'));


for i=1:L
    Istruct = zeros(S.ImageSize);
    Istruct(S.PixelIdxList{i}) = 1;
    I=imcrop(Istruct,[B{i}(1) B{i}(2) B{i}(3) B{i}(4)]);
    Ss=bwconncomp(I);
    Ii = zeros(Ss.ImageSize);
    s1 = regionprops(I,'centroid');
    g1 = ceil(s1.Centroid);
    Ii(g1(2),g1(1))= 1;
    Ss=bwconncomp(Ii);
    ctr(i) =Ss.PixelIdxList{1}; 
    [SF{i}] = shapefactor_object(I,ctr);
end
end

