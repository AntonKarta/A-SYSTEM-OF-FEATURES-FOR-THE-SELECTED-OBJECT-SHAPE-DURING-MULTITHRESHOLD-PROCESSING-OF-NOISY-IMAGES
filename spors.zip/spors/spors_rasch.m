clear all
close all

A_b=readmatrix('SF1.xls');
E_i=readmatrix('SF2.xls'); L_c=readmatrix('SF3.xls'); 
S_c=readmatrix('SF4.xls'); T_f=readmatrix('SF5.xls');
s1=1; s2=2;

m1=mean(E_i(:,s1));  m2=mean(E_i(:,s2));
coef=[m1 m2];
% 
% for a=1:6
% i=randi([1,5]);
% name=[num2str(i) '.jpg'];
% I=imread(name);
% if a==1
%    I_n=I;
% else
%     I_n=[I_n I];
% end
% end

I_n=imread('Entoloma-incanum-2019-08-22-spore-40-1140.jpg');

d=0.1;  S_min = 500;

[Istina] = uistina_v1_2(I_n,d,coef,S_min,s1,s2);

S=bwconncomp(Istina);
B=struct2cell(regionprops(S,'BoundingBox'));
s=size(B);
imagesc(I_n);
hold on
for i=1:s(2)
rectangle('Position',ceil(B{i}),'EdgeColor','r')
text((ceil(B{i}(1))),(ceil(B{i}(2)-5)),'\downarrow Entoloma');
end