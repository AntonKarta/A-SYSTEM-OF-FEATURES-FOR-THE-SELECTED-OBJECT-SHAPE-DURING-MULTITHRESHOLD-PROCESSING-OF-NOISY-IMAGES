function [LL] = razvert(Im)
Im=medfilt2(Im, [20,20],'symmetric');
angle=0:1:360;
N=length(angle);
for a = 1:N
I=imrotate(Im,angle(a));
I=I>0;
S = bwconncomp(I);
B=regionprops(S,'BoundingBox');
I= imcrop(I,[B.BoundingBox(1) B.BoundingBox(2)...
B.BoundingBox(3) B.BoundingBox(4)]);
Ss = bwconncomp(I);
I2 = zeros(Ss.ImageSize);
s1 = regionprops(Ss,'centroid');
g1=round(s1.Centroid);
cort=g1(1);
while I(g1(2),cort)~=0
    cort=cort+1;
end
I2(g1(2),cort)= 2;
I=I+I2;
distanse=g1(1):cort;
L(a)=length(distanse);
for i=1:L(a)
    I(g1(2),distanse(i))=3;
end
% figure (1)
% imagesc(I);
end

[p,s]=max(L);

Dmin=L(1:s-1); Dmax=L(s:361);

L=[Dmax Dmin]/p;

LL=L;
 for i = 2:1:length(L)-2
     LL(i)=(L(i)+L(i-1)+L(i+1))./3;
 end

end

