clear all

Im=imread('II.bmp');

I=Im>1;
Smin=100; Pmax=500;
S1=bwconncomp(I);

Iz = zeros(S1.ImageSize);
s1 = regionprops(I,'centroid');
g1 = [66,52];
Iz(g1(2),g1(1))= 1;
Ss=bwconncomp(Iz);
center =Ss.PixelIdxList{1};

[I_M,SF] = shapefactor_object(I,center);
sf=[SF(2),SF(6)];
[LL] = razvert(I_M);

cloi=zeros(1,101);

for S=1:101
snois=S-1
for col=1:100
ind=0;
R=snois*randn(103,129);
Imk=I*180;
Imref=uint8(Imk);
Noise = Imk + R;
Noise_im=uint8(Noise);

thresh = multithresh(Noise_im);
I_T=Noise_im>thresh;
S2=bwconncomp(I_T);
[~,m]=size(S2.PixelIdxList);
for i=1:m
    l(i)=length(S2.PixelIdxList{i});
end
[~,ind]=max(l);
A=struct2cell(regionprops(S2,'Area'));
Ar=A{ind(1)};
P=struct2cell(regionprops(S2,'Perimeter'));
Pr=P{ind(1)};
if Ar>Smin && Pr<Pmax 
IM=zeros(S1.ImageSize);
IM(S2.PixelIdxList{ind})=1;
[I_Mn,SFn] = shapefactor_object(IM,center);
sfn=[SF(2),SF(6)];
dist=pdist2(sfn,sf);
    if dist<0.01
    cloi(S)=cloi(S)+1;
    end
end
end
end