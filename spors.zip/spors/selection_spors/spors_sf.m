% clear all
% close all
% 
%  I1=imread('AB.jpg');
% [S_c1] = new_SF_dist(I1);

% I2=imread('EL.jpg');
% [S_c2] = new_SF_dist(I2);
% 
% I3=imread('LC.jpg');
% [S_c3] = new_SF_dist(I3);
% 
% I4=imread('SC.jpg');
% [S_c4] = new_SF_dist(I4);
% 
% 
% I5=imread('TF.jpg');
% [S_c5] = new_SF_dist(I5);


clear I1 I2 I3 I4 I5

for i=1:23
   hold on
   plot (S_c5(i,:))
end


% n1=8;
% n2=5;
% 
% S11=SS1(:,n1); S12=SS1(:,n2);
% S21=SS2(:,n1); S22=SS2(:,n2);
% S31=SS3(:,n1); S32=SS3(:,n2);
% S41=SS4(:,n1); S42=SS4(:,n2);
% S51=SS5(:,n1); S52=SS5(:,n1);
% 
% plot(S11,S12,'.');
% hold on
% plot(S21,S22,'.');
% plot(S31,S32,'.');
% plot(S41,S42,'.');
% plot(S51,S52,'.');