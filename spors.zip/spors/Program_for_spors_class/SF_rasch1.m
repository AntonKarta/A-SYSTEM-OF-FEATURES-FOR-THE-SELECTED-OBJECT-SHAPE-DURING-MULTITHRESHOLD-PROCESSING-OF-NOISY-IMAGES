function [SS,L] = SF_rasch1(Im)
Im=rgb2gray(Im);
bw=Im>150;
% bw = bwareaopen(bw,30);
% bw = imfill(bw,'holes');
S=bwconncomp(bw);
L=S.NumObjects;
B=struct2cell(regionprops(S,'BoundingBox'));

angle=0:5:360;
N=length(angle);
for i=1:L
     if length(S.PixelIdxList{i})>10
    Istruct = zeros(S.ImageSize);
    Istruct(S.PixelIdxList{i}) = 1;
    I=imcrop(Istruct,[B{i}(1) B{i}(2) B{i}(3) B{i}(4)]);
    imshow(I)
    for a=1:N
    Il=imrotate(I,angle(a));
    Ss=bwconncomp(Il);
    Ii = zeros(Ss.ImageSize);
    s1 = regionprops(Il,'centroid');
    g1 = ceil(s1.Centroid);
    Ii(g1(2),g1(1))= 1;
    Ss=bwconncomp(Ii);
    ctr =Ss.PixelIdxList{1}; 
    [SF{a}] = shapefactor_object(Il,ctr);
    end
    [SSF{i}]= shape(SF,N);
    if i==1
    SS=[SSF{i}];
    else
        SS=[SS; SSF{i}];
    end
    end
end
end

