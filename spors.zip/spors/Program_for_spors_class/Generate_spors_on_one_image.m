clear all
clc
close all

Por1=0.2;Por2=1;Por3=0.99;
ss1=1;ss2=2;

SFc=open('SF.mat'); SF_f=SFc.S_f4; col=[SF_f(:,ss1) SF_f(:,ss2)];

SRc=open('SR.mat'); SF_r=SRc.S_r4; [L_r,~]=size(SF_r);

SDc=open('SD.mat'); SF_d=SDc.S_d4; [L_d,~]=size(SF_d);

for i=1:6
%%
Rand=randi([1,4]);
name=[num2str(Rand), '.jpg'];

Img=imread(name);
Img=rgb2gray(Img);
Img=Img>50;

S = bwconncomp(Img);
Rand_obg=randi([1,S.NumObjects]);

Il=zeros(S.ImageSize);
Il(S.PixelIdxList{Rand_obg})=255;

B=struct2cell(regionprops(S,'BoundingBox'));
I_crop=imcrop(Il,[B{Rand_obg}(1), B{Rand_obg}(2),...
    B{Rand_obg}(3), B{Rand_obg}(4)]);

S_c = bwconncomp(I_crop);
%%
Im=I_crop>150;
S_cl = bwconncomp(Im);

I = zeros(S_cl.ImageSize);
s1 = regionprops(Im,'centroid');
g1=0;
g1 = ceil(s1.Centroid);

I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
center =Ss.PixelIdxList{1};  % нахождения центра фигуры

[SF{i}] = shapefactor_object(I_crop,center);

Sf=SF{i};
Sf=Sf';

S1(i)=Sf(:,ss1);S2(i)=Sf(:,ss2);
Sf=[Sf(:,ss1) Sf(:,ss2)];

dis=pdist2(Sf,col);
minF(i)=min(dis);


[LL] = dist_round(Im);
for k=1:L_r
    Srav=SF_d(k,:);
    Cov(k)=corr2(LL,Srav);
end

maxD(i)=max(Cov);
%%
gmI=max(I_crop(:))-I_crop;
Iz=zeros(S_c.ImageSize);

name=['l', num2str(Rand), '.jpg'];

Img_rgb=imread(name);
I_crop_rgb=imcrop(Img_rgb,[B{Rand_obg}(1), B{Rand_obg}(2),...
    B{Rand_obg}(3), B{Rand_obg}(4)]);
Img_gray=rgb2gray(I_crop_rgb);

Iz=(Img_gray-uint8(gmI));
Siz{i}=size(Iz);
Ix{i}=Iz;
end

IL=Ix{1}; Iy = Ix{1}>0;

for i=1:6
    Coli(i)=0;
    if i==1
        IL=Ix{1}; 
        Iy = Ix{1}>0;
        SB1 = bwconncomp(Iy);
    if  Por3>maxD(i)
    Coli(i)=i;
    Iy= zeros(SB1.ImageSize);
    end

else    
scale(i)=Siz{1}(1)/Siz{i}(1);
Ix{i} = imresize(Ix{i},scale(i), 'nearest');
IL=[IL,Ix{i}];

scale(i)=Siz{1}(1)/Siz{i}(1);

Ilk{i} = Ix{i}>0;

SB = bwconncomp(Ilk{i});

if  Por3>maxD(i)
    Coli(i)=i;
    Ilk{i}= zeros(SB.ImageSize);
end

Iy=[Iy,Ilk{i}];

end
end

Istina=Iy;
S=bwconncomp(Istina);
B=struct2cell(regionprops(S,'BoundingBox'));
s=size(B);

figure (1)
rgbImage = ind2rgb(IL, colormap(hot));
imshow(rgbImage)

hold on
for i=1:s(2)
rectangle('Position',ceil(B{i}),'EdgeColor','g','LineWidth',2,'LineStyle','--')
text((ceil(B{i}(1))),(ceil(B{i}(2)-5)),'\downarrow');
end

Coli(Coli==0) = []; 

for i=1:length(Coli)
    S1t(i)=S1(Coli(i));
    S2t(i)=S2(Coli(i));
end


%% ввод площади
SF_t1=SFc.S_f1; SF_t2=SFc.S_f2; SF_t3=SFc.S_f3; SF_t4=SFc.S_f4; SF_t5=SFc.S_f5;    

figure (2)
plot(SF_t1(:,ss1),SF_t1(:,ss2),'+');
hold on
grid on
plot(SF_t2(:,ss1),SF_t2(:,ss2),'+');
plot(SF_t3(:,ss1),SF_t3(:,ss2),'+');
plot(SF_t4(:,ss1),SF_t4(:,ss2),'+');

plot(S1,S2,'o', 'MarkerFaceColor','g');

plot(S1t,S2t,'o', 'MarkerFaceColor','r');

legend('Шампиньо́н двуспо́ровый','Энтолома седая','Лепиота шерстистообутая','Строфария небесно-синяя','Верный выбор','Не верный выбор');