function [S_c] = new_SF(I1)

Im1=rgb2gray(I1);
bw=Im1>150;
S = bwconncomp(bw);

for i=1:S.NumObjects
    if length(S.PixelIdxList{i})>500
    I = zeros(S.ImageSize);
    I(S.PixelIdxList{i}) = 255;
    if i==1
        [LL] = razvert(I);
        S_c=LL;
    else
       [LL] = razvert(I);
        S_c=[S_c;LL];
    end
    end
end

end

