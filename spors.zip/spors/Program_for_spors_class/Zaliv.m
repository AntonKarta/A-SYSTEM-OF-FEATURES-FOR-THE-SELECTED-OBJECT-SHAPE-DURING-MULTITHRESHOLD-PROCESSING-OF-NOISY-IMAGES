function [bim] = Zaliv(I)
bim = I;
[w h] = size(bim);

S=bwconncomp(I);
ss = regionprops(S,'centroid');
G = ceil(ss.Centroid);

newColor = 255; oldColor = 0;
point.x = G(2); point.y = G(1);

stack = [point];

spanLeft = 0; spanRight = 0;

while (length(stack) ~=0)
  point = stack(1);  
  stack(1) = []; % Удаляем закрашенную точку из стека
  y1 = point.y;
  
  % Находим границу слева
  while (y1 >= 1 && bim(point.x,y1) == oldColor) y1 = y1 - 1; end;
  y1 = y1 + 1;
  spanLeft = 0; spanRight = 0;
  %Топаем по строке от левой границы вправо
  while (y1 < h && bim(point.x,y1) == oldColor)
    bim(point.x,y1) = newColor; %Закрашиваем текущую точку 
    if (spanLeft == 0 && point.x > 0 && bim(point.x-1,y1) == oldColor)
      newpoint.x = point.x-1; newpoint.y = y1; stack = [stack newpoint];
      spanLeft = 1;
    elseif (spanLeft == 1 && point.x > 0 && bim(point.x-1,y1) ~= oldColor)
        spanLeft = 0;
    end;
    
    if (spanRight == 0 && point.x < w && bim(point.x+1,y1) == oldColor)
      newpoint.x = point.x+1; newpoint.y = y1; stack = [stack newpoint];
      spanRight= 1;
    elseif (spanRight == 1 && point.x < w && bim(point.x+1,y1) ~= oldColor)
      spanRight = 0;
    end;
    y1 = y1 + 1;
  end; 
end;
end

