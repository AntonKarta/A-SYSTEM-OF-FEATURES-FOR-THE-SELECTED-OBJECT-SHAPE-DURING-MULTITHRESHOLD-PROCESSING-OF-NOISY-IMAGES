clear all
close all
clc
 
 I1=imread('sporz_circ.png');
[S_c] = new_SF_dist(I1);


% I2=imread('2.jpg');
% [S_d2] = new_SF_dist(I2);
% 
% I3=imread('3.jpg');
% [S_d3] = new_SF_dist(I3);
% 
% I4=imread('4.jpg');
% [S_d4] = new_SF_dist(I4);
% 
% 
% I5=imread('5.jpg');
% [S_d5] = new_SF_dist(I5);
