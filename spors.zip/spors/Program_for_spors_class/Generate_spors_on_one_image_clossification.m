clear all
clc
close all

Por1=0.2;Por2=1;Por3=0.99;
ss1=1;ss2=2;

SFc=open('SF.mat'); SF_f=SFc.S_f4; col=[SF_f(:,ss1) SF_f(:,ss2)];
SF_t1=SFc.S_f1; SF_t2=SFc.S_f2; SF_t3=SFc.S_f3; SF_t4=SFc.S_f4; SF_t5=SFc.S_f5;    
col1=[SF_t1(:,ss1) SF_t1(:,ss2)]; col2=[SF_t2(:,ss1) SF_t2(:,ss2)];
col3=[SF_t3(:,ss1) SF_t3(:,ss2)]; col4=[SF_t4(:,ss1) SF_t4(:,ss2)];

SRc=open('SR.mat'); SF_r=SRc.S_r4; [L_r,~]=size(SF_r);

SDc=open('SD.mat'); SF_d=SDc.S_d4; 
SF_d1=SDc.S_d1; SF_d2=SDc.S_d2; SF_d3=SDc.S_d3; SF_d4=SDc.S_d4; SF_d5=SDc.S_d5; 
[L_d1,~]=size(SF_d1); [L_d2,~]=size(SF_d2); [L_d3,~]=size(SF_d3); [L_d4,~]=size(SF_d4);

for i=1:6
%%
Rand=randi([1,4]);
name=[num2str(Rand), '.jpg'];

Img=imread(name);
Img=rgb2gray(Img);
Img=Img>150;

S = bwconncomp(Img);

Rand_obg=randi([1,S.NumObjects]);

Il=zeros(S.ImageSize);
Il(S.PixelIdxList{Rand_obg})=255;

B=struct2cell(regionprops(S,'BoundingBox'));
I_crop=imcrop(Il,[B{Rand_obg}(1), B{Rand_obg}(2),...
    B{Rand_obg}(3), B{Rand_obg}(4)]);

S_c = bwconncomp(I_crop);
%%
Im=I_crop>150;
S_cl = bwconncomp(Im);

I = zeros(S_cl.ImageSize);
s1 = regionprops(Im,'centroid');
g1=0;
g1 = ceil(s1.Centroid);

I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
center =Ss.PixelIdxList{1};  % нахождения центра фигуры
%%
[SF{i}] = shapefactor_object(I_crop,center);

Sf=SF{i};
Sf=Sf';
Sk1(i)=Sf(:,ss1);Sk2(i)=Sf(:,ss2);
Sf=[Sf(:,ss1) Sf(:,ss2)];
%%

dis1=pdist2(Sf,col1);
minF1(i)=min(dis1);

dis2=pdist2(Sf,col2);
minF2(i)=min(dis2);

dis3=pdist2(Sf,col3);
minF3(i)=min(dis3);

dis4=pdist2(Sf,col4);
minF4(i)=min(dis4);

%%
[LL] = dist_round(Im);

for k=1:L_d1
    Srav=SF_d1(k,:);
    Cov1(k)=corr2(LL,Srav);
end
maxD1(i)=max(Cov1);

for k=1:L_d2
    Srav=SF_d2(k,:);
    Cov2(k)=corr2(LL,Srav);
end
maxD1(i)=max(Cov2);

for k=1:L_d3
    Srav=SF_d3(k,:);
    Cov3(k)=corr2(LL,Srav);
end
maxD3(i)=max(Cov3);

for k=1:L_d4
    Srav=SF_d4(k,:);
    Cov4(k)=corr2(LL,Srav);
end
maxD4(i)=max(Cov4);

%%
gmI=max(I_crop(:))-I_crop;
Iz=zeros(S_c.ImageSize);

name=['l', num2str(Rand), '.jpg'];

Img_rgb=imread(name);
I_crop_rgb=imcrop(Img_rgb,[B{Rand_obg}(1), B{Rand_obg}(2),...
    B{Rand_obg}(3), B{Rand_obg}(4)]);
Img_gray=rgb2gray(I_crop_rgb);

Iz=(Img_gray-uint8(gmI));
Siz{i}=size(Iz);
Ix{i}=Iz;
end

Mimimal=[minF1;minF2;minF3;minF4];

IL=Ix{1};Iy = Ix{1}>0;

for i=1:6
    Coli(i)=0;
    if i==1
        IL=Ix{1}; 
        Iy = Ix{1}>0;
        SB1 = bwconncomp(Iy);
        [~,M(i)]=min(Mimimal(:,i));
        Iy=Iy*M(i);
else    
scale(i)=Siz{1}(1)/Siz{i}(1);
Ix{i} = imresize(Ix{i},scale(i), 'nearest');
IL=[IL,Ix{i}];

scale(i)=Siz{1}(1)/Siz{i}(1);
[~,M(i)]=min(Mimimal(:,i));

Ilk{i} = Ix{i}>0;
Ilk{i}=M(i)*Ilk{i};

SB = bwconncomp(Ilk{i});

Iy=[Iy,Ilk{i}];

end
end

Istina1=Iy==1;
Istina2=Iy==2;
Istina3=Iy==3;
Istina4=Iy==4;

S1=bwconncomp(Istina1);
B1=struct2cell(regionprops(S1,'BoundingBox'));
sd1=size(B1);

S2=bwconncomp(Istina2);
B2=struct2cell(regionprops(S2,'BoundingBox'));
sd2=size(B2);

S3=bwconncomp(Istina3);
B3=struct2cell(regionprops(S3,'BoundingBox'));
sd3=size(B3);

S4=bwconncomp(Istina4);
B4=struct2cell(regionprops(S4,'BoundingBox'));
sd4=size(B4);

figure (1)
hold on
rgbImage = ind2rgb(IL, colormap(hot));
imshow(rgbImage)

for i=1:sd1(2)
rectangle('Position',ceil(B1{i}),'EdgeColor','b','LineWidth',2,'LineStyle','-')
text((ceil(B1{i}(1))),(ceil(B1{i}(2)-5)),'\downarrow');
end

for i=1:sd2(2)
rectangle('Position',ceil(B2{i}),'EdgeColor','r','LineWidth',2,'LineStyle','-')
text((ceil(B2{i}(1))),(ceil(B2{i}(2)-5)),'\downarrow');
end

for i=1:sd3(2)
rectangle('Position',ceil(B3{i}),'EdgeColor','g','LineWidth',2,'LineStyle','-')
text((ceil(B3{i}(1))),(ceil(B3{i}(2)-5)),'\downarrow');
end

for i=1:sd4(2)
rectangle('Position',ceil(B4{i}),'EdgeColor','m','LineWidth',2,'LineStyle','-')
text((ceil(B4{i}(1))),(ceil(B4{i}(2)-5)),'\downarrow');
end





%% ввод площади

figure (2)
plot(SF_t1(:,ss1),SF_t1(:,ss2),'+');
hold on
grid on
plot(SF_t2(:,ss1),SF_t2(:,ss2),'+');
plot(SF_t3(:,ss1),SF_t3(:,ss2),'+');
plot(SF_t4(:,ss1),SF_t4(:,ss2),'+');

plot(Sk1,Sk2,'o', 'MarkerFaceColor','g');

% legend('Шампиньо́н двуспо́ровый','Энтолома седая','Лепиота шерстистообутая','Строфария небесно-синяя');