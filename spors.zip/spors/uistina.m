function [Istina] = uistina(Im,razni,coef1,S_min)

T_max = 255;	T_step = 1; [L,D]=size(coef1);
Im=rgb2gray(Im);Im=max(Im(:))-Im;

for T=1:T_step:T_max
    I_T = (Im >= T);
    I_T = bwareaopen(I_T,30);
    S{T} = bwconncomp(I_T);
    
    I = zeros(S{T}.ImageSize);
    Istruct = zeros(S{T}.ImageSize);
    raz{T} = NaN(S{T}.NumObjects,1);
    
    disp(T);
    I_P{T} = zeros(S{T}.ImageSize);
    II=zeros(S{T}.ImageSize);
    I1 = zeros(S{T}.ImageSize);
    Ii{T} = zeros(S{T}.ImageSize);
    if T==1
    Istina=zeros(S{T}.ImageSize);
    I_z=zeros(S{T}.ImageSize);
    end
    cnt_obj = 0;
    size_obj = [];
    
    
    for i=1:S{T}.NumObjects
        if (length(S{T}.PixelIdxList{i}) > S_min)
        I1(S{T}.PixelIdxList{i})=1;
        Sis=bwconncomp(I1);
        s1 = regionprops(I1,'centroid');
        g1=0;
        g1 = ceil(s1.Centroid);
        Ii{T}(g1(2),g1(1))= 1;
        Ss=bwconncomp(Ii{T});
        ctr=Ss.PixelIdxList{1};
        
        A = regionprops(Sis,'Area');
        MaxD = regionprops(Sis,'MaxFeretProperties');
        MinD = regionprops(Sis,'MinFeretProperties');
        E = regionprops(Sis,'Eccentricity');
        P = regionprops(Sis,'Perimeter');
        
        
        for j=1:Sis.NumObjects
        if sum(Sis.PixelIdxList{j}==ctr) > 0
        break;
        end
        end
     
      SF8 = 4 * A(j).Area / (MaxD(j).MaxFeretDiameter.^2);
      SF2 = MaxD(j).MaxFeretDiameter / MinD(j).MinFeretDiameter;
%       SF6 = E(j).Eccentricity;
%       P_s=P.Perimeter;
      t_n1{T}{i}=[SF2 SF8];
%       t_n2{T}{i}=[SF2 SF6];
      for l=1:L
         dis(l)= pdist2(t_n1{T}{i},coef1(l,:));
      end    
      Min=min(dis);
      raz1{T}(i)=Min; 
%       raz2{T}(i)=pdist2(t_n2{T}{i},coef2);
      I1 = zeros(S{T}.ImageSize);
      
        if (raz1{T}(i) < razni)
%         if (raz2{T}(i) < razni)
%         if (P_s < P_max)
                I_P{T}(S{T}.PixelIdxList{i}) = T; % попробовать заменить Istina на данную переменную
                Istina(S{T}.PixelIdxList{i})=T;
                I_z(S{T}.PixelIdxList{i}) = 1;
        end
        end
        end
%         end
%         end
end
end

