clear all
close all

I1=imread('Agaricus-bisporus-2016-05-09-spore-100-359.jpg');
Im1=rgb2gray(I1);
Im1=max(Im1(:))-Im1;
bw=Im1>50;
bw = bwareaopen(bw,30);
imshow(bw);
S = bwconncomp(bw);

for i=1:S.NumObjects
    tic
    I = zeros(S.ImageSize);
    I(S.PixelIdxList{i}) = 255;
    if i==1
        [LL] = razvert(I);
        S_c=LL;
    else
       [LL] = razvert(I);
        S_c=[S_c;LL];
    end
     toc 
end