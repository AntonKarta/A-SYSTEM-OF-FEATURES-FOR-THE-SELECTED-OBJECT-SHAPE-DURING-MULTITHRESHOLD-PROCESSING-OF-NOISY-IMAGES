clear all
close all

I1=imread('Agaricus-bisporus-2016-05-09-spore-100-359.jpg');
[S_c1] = new_SF(I1,50);

I2=imread('Entoloma-incanum-2019-08-22-spore-40-1140.jpg');
[S_c2] = new_SF(I2,40);

I3=imread('Lepiota-clypeolaria-2015-08-22-spore-40.jpg');
[S_c3] = new_SF(I3,50);

I4=imread('Stropharia-caerulea-2016-11-27-spore-100-295.jpg');
[S_c4] = new_SF(I4,50);

I5=imread('Tubaria-furfuracea-2016-05-26-spore-100-325.jpg');
[S_c5] = new_SF(I5,50);

clear I1 I2 I3 I4 I5