clear all

for k=1:25
name=['D:\DiplomMAG\spors\AB\', num2str(k),'.jpg']; 
Im=imread(name);

Im1=rgb2gray(Im);
Im1=max(Im1(:))-Im1;
Signal=Im1>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im1] = Zaliv(Im);

[LL{k}] = razvert(Im1);
end
