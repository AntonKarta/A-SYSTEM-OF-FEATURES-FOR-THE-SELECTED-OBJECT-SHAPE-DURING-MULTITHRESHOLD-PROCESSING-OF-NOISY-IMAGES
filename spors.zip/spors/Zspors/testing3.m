clc; clear all; close all


Li=struct2cell(open('L_dist.mat'));
Li1=Li{1}{6};

L = 361;  % Total length (points)
LS1 = 361; % Length (duration) of signal (points)
LS2 = 361;  % 
LD1 = 0;  % Signal appearance [points] 
LD2 = 0;
%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%
   PROCESS = 1 % Signal
s1=Li{1}{1};
P1 = sum(s1.^2) % Power

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k=1:25
s2=Li{1}{k};
P2 = sum(s2.^2) % Power

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sDIF = s1 - s2;

L1 = max(LD1,LD2) 
L2 = min(LD1+LS1,LD2+LS2)  % 501 
LS12 = L2 - L1; % 20
PDIF = sum(sDIF.^2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s12 = s1.*s2;
P12 = sum(s12(:))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = 1000; %M = 2;
PETM = zeros(M,1);
PD1 = zeros(M,1); PM1 = zeros(M,1); 
PD2 = zeros(M,1); PM2 = zeros(M,1);
PDD1 = zeros(M,1); PDD2 = zeros(M,1);

cy1sDIF = zeros(L,1); cy2sDIF = zeros(L,1);
cn1sDIF = zeros(L,1);
%%%%%%%%%%%%%%%%%%%%%%%%
for s=1:101
sd_noise = s-1; %  %%%%%%%%%%%%%%  Standard Deviation of Noise
%%%%%%%%%%%%%%%%%%%%%%%%
THR = (P1 - P2)/2
THRn = PDIF/2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n1 = sd_noise*randn(size(s1));% n2 = sd_noise*randn(size(t)); 
y1 = s1 + n1; % Signal plus noise
y2 = s2 + n1; % Signal plus the same noise !!!!

cy1sDIF(1) = y1(1)*sDIF(1);
cy2sDIF(1) = y2(1)*sDIF(1);
cn1sDIF(1) = n1(1)*sDIF(1);

for i = 2:L
cy1sDIF(i)=cy1sDIF(i-1)+y1(i)*sDIF(i); 
cy2sDIF(i)=cy2sDIF(i-1)+y2(i)*sDIF(i);
cn1sDIF(i)=cn1sDIF(i-1)+n1(i)*sDIF(i);
end

zy1sDIF = cy1sDIF(L2); zy2sDIF = cy2sDIF(L2);
zn1sDIF = cn1sDIF(L2);

Cy1s1 = 0; Cy1s2 = 0; Cy2s1 = 0; Cy2s2 = 0; Cn1sDIF = 0;
if (zy1sDIF)>THR, Cy1s1 = 1; PD1(1) = 1; end;
if (zy2sDIF)>THR, Cy2s1 = 1; PM2(1) = 1; end;
if (zy1sDIF)<THR, Cy1s2 = 1; PM1(1) = 1;end;
if (zy2sDIF)<THR, Cy2s2 = 1; PD2(1) = 1; end;
if (zn1sDIF)<-THRn,  Cn1sDIF = 0; PDD1(2) = 1; end;
if (zn1sDIF)>THRn,   Cn1sDIF = 1; PDD1(1) = 1; end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  m > 1  %%%%%%%%%%%%%%%%%%%%%%
for m = 2:1:M
 
 disp(m)
%%%% rand('state',0);
n1 = sd_noise*randn(size(s1));
y1 = s1 + n1; % Signal plus noise
y2 = s2 + n1; % Signal plus the same noise !!!!

 cy1s1(1) = y1(1)*s1(1); cy1s2(1) = y1(1)*s2(1);
 cy2s1(1) = y2(1)*s1(1); cy2s2(1) = y2(1)*s2(1);
 cy1sD(1) = y1(1)*sDIF(1); cy2s12(1) = y2(1)*sDIF(1);
 cn1s12(1) = n1(1)*sDIF(1);
for i = 2:L

cy1sDIF(i) = cy1sDIF(i-1)+y1(i)*sDIF(i);
cy2sDIF(i) = cy2sDIF(i-1)+y2(i)*sDIF(i);
cn1sDIF(i)=cn1sDIF(i-1)+n1(i)*sDIF(i);
end;
zy1sDIF = cy1sDIF(L2); zy2sDIF = cy2sDIF(L2);
zn1sDIF = cn1sDIF(L2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cy1s1 = 0; Cy1s2 = 0; Cy2s1 = 0; Cy2s2 = 0; Cn1sDIF = 0;
% L2 = L2
if (zy1sDIF)>THR, Cy1s1 = 1; end;
if (zy2sDIF)>THR, Cy2s1 = 1; end;
if (zy1sDIF)<THR, Cy1s2 = 1; end;
if (zy2sDIF)<THR, Cy2s2 = 1; end;
if (zn1sDIF)<-THRn, Cn1sDIF = 0; end;
if (zn1sDIF)>THRn,  Cn1sDIF = 1; end;
PD1(m) = PD1(m-1)*(m-1)/m + Cy1s1/m;
PD2(m) = PD2(m-1)*(m-1)/m + Cy2s2/m;
PM2(m) = PM2(m-1)*(m-1)/m + Cy2s1/m;
PM1(m) = PM1(m-1)*(m-1)/m + Cy1s2/m;
PDD1(m) = PDD1(m-1)*(m-1)/m + Cn1sDIF/m;
PDD2(m) = PDD2(m-1)*(m-1)/m + Cn1sDIF/m;


end;

PD1M = PD1(M);
PD2M = PD2(M);
PM1M = PM1(M);
PM2M = PM2(M);
PEM{k}(s) = (PM1M + PM2M)/2;
PE1{k}(s) = (1 - PD1M + PM1M)/2;
PE2{k}(s) = (1 - PD2M + PM2M)/2;

PDD1M = PDD1(M);
PDD2M = PDD2(M);
PEDDM = (1-PDD1M)/2 + (1-PDD2M)/2;

sd_noise = sd_noise;
PNOISE = sd_noise*LS12;
q1 = P1/PNOISE;
q2 = P2/PNOISE;
%%%%%%%%%%%%%%%%%%%%%%%%%%%   

qDIF = PDIF/PNOISE;
h = sqrt(qDIF/2);
PET{k}(s) = 1 - normcdf(h,0,1);
clc
end

end