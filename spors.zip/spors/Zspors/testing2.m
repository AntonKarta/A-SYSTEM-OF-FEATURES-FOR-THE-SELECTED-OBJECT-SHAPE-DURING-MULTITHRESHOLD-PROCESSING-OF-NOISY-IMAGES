clear all
clc
% close all

m=200; n=200;
r=1;
name=['D:\DiplomMAG\spors\AB\', num2str(r),'.jpg']; 
Im1=imread(name);
Im1=rgb2gray(Im1);
Im1=max(Im1(:))-Im1;
Signal=Im1>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im1] = Zaliv(Im);
S=bwconncomp(Im1); Aria_1=struct2array(regionprops(S,'Area'));

% figure (1); imshow(Im1)

for k=1:2
r=3;
name=['D:\DiplomMAG\spors\AB\', num2str(k),'.jpg']; 
Im=imread(name);
Im=rgb2gray(Im);
Im=max(Im(:))-Im;
Signal=Im>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im2] = Zaliv(Im);
S=bwconncomp(Im2); Aria_2=struct2array(regionprops(S,'Area'));

% figure (2); imshow(Im2)

s1 = Im1/255; s2 = Im2/255;

 s1sq = s1.^2;  
 P1 = sum(s1sq(:)); % Disk Power
 s2sq = s2.^2;  
 P2 = sum(s2sq(:)); % Rect Power
 PDIFF = P1 - P2 % Difference of Power
 
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 sDIF = s1 - s2;
%  figure(1030), imshow(sDIF,[]), title('sDIF Diff Image')
 AsDIF = abs(sDIF); 
 SID = sum(AsDIF(:)); % Square for Accumulation
 sDIFsq = sDIF.^2;
 %figure(1031), imshow(sDIFsq,[]), title('Diff Squared Image')
 PDIF = sum(sDIFsq(:)); % Power Diff Signal
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 s12 = s1.*s2;
 %figure(1040), imshow(s12,[]), title('s12 Mutual Image')
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 for s=1:101
 sd_noise = s-1;
 
 % ts = input('STOP1','s');  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M1 = 200; % M1 = 2
PETM = zeros(M1,1);
PD1 = zeros(M1,1); PM1 = zeros(M1,1);
PD2 = zeros(M1,1); PM2 = zeros(M1,1); 

THR = (P1 - P2)/2;

y1 = s1 + sd_noise*randn(m,n); % Signal plus noise
y2 = s2 + sd_noise*randn(m,n); % Signal plus noise
 cy1s12 = conv2(y1,sDIF,'same');  cy2s12 = conv2(y2,sDIF,'same');
 x0 = 100; y0 = 100;
if (cy1s12(y0,x0) - THR)>0, PD1(1) = 1; end; % Cy1s1 = 1;
if (cy1s12(y0,x0) - THR)<0, PM1(1) = 1; end; % Cy1s2 = 1;
if (cy2s12(y0,x0) - THR)>0, PM2(1) = 1; end; % Cy2s1 = 1; 
if (cy2s12(y0,x0) - THR)<0, PD2(1) = 1; end; % Cy2s2 = 1; 

for m1 = 2:1:M1
 
%%%% rand('state',0);
y1 = s1 + sd_noise*randn(m,n); % Signal plus noise
y2 = s2 + sd_noise*randn(m,n); % Signal plus noise

cy1s12 = conv2(y1,sDIF,'same');  cy2s12 = conv2(y2,sDIF,'same');
Cy1s1 = 0; Cy1s2 = 0; Cy2s1 = 0; Cy2s2 = 0;

if (cy1s12(y0,x0) - THR)>0, Cy1s1 = 1; end 
if (cy1s12(y0,x0) - THR)<0, Cy1s2 = 1; end
if (cy2s12(y0,x0) - THR)>0, Cy2s1 = 1; end
if (cy2s12(y0,x0) - THR)<0, Cy2s2 = 1; end  

PD1(m1) = PD1(m1-1)*(m1-1)/m1 + Cy1s1/m1;
PD2(m1) = PD2(m1-1)*(m1-1)/m1 + Cy2s2/m1;
PM2(m1) = PM2(m1-1)*(m1-1)/m1 + Cy2s1/m1;
PM1(m1) = PM1(m1-1)*(m1-1)/m1 + Cy1s2/m1;
  
end

PD1M{k}(s) = PD1(M1);% обнаружение
PD2M = PD2(M1);% обнуружение
PM1M = PM1(M1);% пропуск
PM2M = PM2(M1);% пропуск

PEM{k}(s) = (PM1M + PM2M)/2;

PE1{k}(s) = (1 - PD1M{k}(s)  + PM1M)/2;
PE2{k}(s) = (1 - PD2M + PM2M)/2;

sd_noise = sd_noise;
PNOISE = sd_noise*SID;

h = PDIF/(2*PNOISE);
PET{k}(s) = 1 - normcdf(sqrt(h)); %  Theoretical Prob of Error

s
 end

k
end
