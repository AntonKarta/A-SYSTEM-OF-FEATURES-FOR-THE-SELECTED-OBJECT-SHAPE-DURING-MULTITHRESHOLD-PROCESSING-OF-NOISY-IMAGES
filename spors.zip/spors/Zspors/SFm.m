clear all

r=1;
name=['D:\DiplomMAG\spors\AB\', num2str(r),'.jpg']; 
Im1=imread(name);
Im1=rgb2gray(Im1);
Im1=max(Im1(:))-Im1;
Signal=Im1>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im1] = Zaliv(Im);

S=bwconncomp(Im1); 

s1 = regionprops(S,'centroid');
g1 = ceil(s1.Centroid);
I1(g1(2),g1(1))= 1;
Ss=bwconncomp(I1);
ctr1 =Ss.PixelIdxList{1};

SF1 = shapefactor_object1(Im1,ctr1);
% 
% y1 = s1 + sd_noise*randn(m,n);

r=2;
name=['D:\DiplomMAG\spors\AB\', num2str(r),'.jpg']; 
Im2=imread(name);
Im2=rgb2gray(Im2);
Im2=max(Im2(:))-Im2;
Signal=Im2>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im2] = Zaliv(Im);

S=bwconncomp(Im2); 

s1 = regionprops(S,'centroid');
g1 = ceil(s1.Centroid);
I2(g1(2),g1(1))= 1;
Ss=bwconncomp(I2);
ctr1 =Ss.PixelIdxList{1};

SF2 = shapefactor_object1(Im2,ctr1);

P1=SF1(1);
P2=SF2(1);

THR = abs((P1 - P2)/2);

M=10; T=128;


for s=1:101
Sn=s-1;
for m=1:M
cT1=0; cF1=0; cT2=0; cF2=0;
N=(randn(200)); 
% генерация шума на изображении первом

noise=N*Sn;

S = bwconncomp(Im1);
In1=zeros(S.ImageSize);
In1(S.PixelIdxList{1})=255;
In1=In1+noise;
In1=uint8(In1);
It1=In1>T;

S=bwconncomp(It1); 

Len=zeros(1,S.NumObjects);
 for i=1:S.NumObjects
    Len(i)=length(S.PixelIdxList{i});
end
[~,L]=max(Len);
Im = zeros(S.ImageSize); 
Im(S.PixelIdxList{L})=1;
S=bwconncomp(Im); 

s1 = regionprops(S,'centroid');
g1 = ceil(s1.Centroid);
Ic1(g1(2),g1(1))= 1;
Ss=bwconncomp(Ic1);
ctr1 =Ss.PixelIdxList{1};

SFt1 = shapefactor_object1(It1,ctr1(1));
Pt1=SFt1(1);

% генерация шума на изображении втором
% S = bwconncomp(Im2);
% In2=zeros(S.ImageSize);
% In2(S.PixelIdxList{1})=255;
% In2=In2+noise;
% In2=uint8(In2);
% It2=In2>T;
% 
% S=bwconncomp(It2); 
% 
% s1 = regionprops(S,'centroid');
% g1 = ceil(s1.Centroid);
% Ic2(g1(2),g1(1))= 1;
% Ss=bwconncomp(Ic2);
% ctr1 =Ss.PixelIdxList{1};
% 
% SFt2 = shapefactor_object1(It2,ctr1);
% Pt2=SFt2(1);

cloc1=abs(P1-Pt1); 
% cloc2=abs(P2-Pt2);

if (cloc1>THR), cF1=cF1+1; end
if (cloc1<THR), cT1=cT1+1; end
m
end

PT=cT1/M;
PF=cF1/M;

PE(s) = (1 - PT + PF)/2;
end