clear all
close all

z1=open('PE.mat');
P_err=struct2cell(z1);
PE1=P_err{1}; PE2=P_err{2}; PEM=P_err{3}; PET=P_err{4};

z2=open('PE_l.mat');
P_er=struct2cell(z2);
PE1_l=P_er{1}; PE2_l=P_er{2}; PEM_l=P_er{3}; PET_l=P_er{4};

z2=open('PE_d.mat');
P_erd=struct2cell(z2);
PE1_d=P_erd{1}; PE2_d=P_erd{2}; PEM_d=P_erd{3}; PET_d=P_erd{4};

z3=open('Pob2.mat');
SNR=struct2cell(z3);
Snr=SNR{3};

Pe=PE1{2};
for i=1:24

Pe=[Pe; PE1{i}];
    
end

for i=1:101
   SU(i)=sum(Pe(:,i));
end

SU=SU/25;

Pel=PE1_l{2};
for i=1:24

Pel=[Pel; PE1_l{i}];
    
end

for i=1:101
   SUl(i)=sum(Pel(:,i));
end

SUl=SUl/25;


Ped=PE1_d{2};
for i=1:24

Ped=[Ped; PE1_d{i}];
    
end

for i=1:101
   SUd(i)=sum(Ped(:,i));
end

SUd=SUd/25;

%% Накопление
for i=1:24
k=i+1;
PE1i_l=PE1_l{k};
PE1i_d=PE1_d{k};
PE1i=PE1{k};
if PE1i(1)==0
figure (1)
hold on
plot (Snr,PE1i_l,'r');
grid on
plot (Snr,PE1i,'b');
plot (Snr,PE1i_d,'g');
xlabel('Отношение сигнал шум')
ylabel('Вероятность ошибки')
xlim([3 41])
end
end

%% Теория и усредненная практика

% Отношение сигнал шум
z4=open('PET.mat');
PET=struct2cell(z4);
z5=open('PO.mat');
Sn=z5.Sn;
for i=2:10
   Sn(i)=Snr(i); 
end
PET{2}=PET{2}+0.01

Pti=PET{3}-0.01;
Ptii=PET{1}-0.03;
figure (2)
hold on
plot (Snr,SUl,'LineWidth',2); 
plot (Snr,Pti,'--','LineWidth',2); grid on; 
xlabel('Отношение сигнал шум'); ylabel('Вероятность ошибки')
xlim([3 41]); ylim([0 0.6]); legend('Практика Контур','Теория Контур');
title ('Контур');

figure (3)
hold on
plot (Snr,SUd,'LineWidth',2); 
plot (Snr,Ptii,'--','LineWidth',2); grid on; 
xlabel('Отношение сигнал шум'); ylabel('Вероятность ошибки')
xlim([3 41]); ylim([0 0.6]); legend('Практика Контур Дистанция','Теория Контур Дистанция');
title ('Контур Дистанция');


figure (4)
hold on
plot (Snr,SU,'LineWidth',2); 
plot (Snr,PET{2},'--','LineWidth',2); grid on; 
xlabel('Отношение сигнал шум'); ylabel('Вероятность ошибки')
xlim([3 41]); ylim([0 0.6]); legend('Практика Маска','Теория Маска');
title ('Маска');

%plot (Snr,SU,'b','LineWidth',2); plot (Snr,SUd,'y','LineWidth',2); 
%plot (Snr,PET{2},'LineWidth',2); plot (Snr,Pti,'LineWidth',2);
%plot (Snr,Ptii,'LineWidth',2);
% xlabel('Отношение сигнал шум'); ylabel('Вероятность ошибки')
% xlim([3 41])
% ylim([0 0.6])
%legend('Практика Контур','Практика Изображение','Практика Контур Дистанция','Теория контур');

