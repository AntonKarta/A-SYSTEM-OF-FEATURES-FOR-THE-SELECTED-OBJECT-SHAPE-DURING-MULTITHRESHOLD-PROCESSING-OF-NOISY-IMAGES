clear all
clc
close all

r=randi([1,5]);
name=['D:\DiplomMAG\spors\AB\', num2str(r),'.jpg']; 
Im1=imread(name);
Im1=rgb2gray(Im1);
Im1=max(Im1(:))-Im1;
Signal=Im1>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im1] = Zaliv(Im);
S=bwconncomp(Im1); Aria_1=struct2array(regionprops(S,'Area'));

% figure (1); imshow(Im1)

r=randi([1,5]);
name=['D:\DiplomMAG\spors\AB\', num2str(r),'.jpg']; 
Im=imread(name);
Im=rgb2gray(Im);
Im=max(Im(:))-Im;
Signal=Im>50 ; S = bwconncomp(Signal); Im = zeros(S.ImageSize);
Im(S.PixelIdxList{1}) = 255; Im = edge(Im,'Canny');
S=bwconncomp(Im); [~,Max_L]=max(length(S.PixelIdxList));
Im = zeros(S.ImageSize); Im(S.PixelIdxList{Max_L}) = 255;
[Im2] = Zaliv(Im);
S=bwconncomp(Im2); Aria_2=struct2array(regionprops(S,'Area'));

% figure (2); imshow(Im2)

s1 = Im1; s2 = Im2;
s1sq = s1.^2;  P1 = sum(s1sq(:)); % Мощность первой фигуры
s2sq = s2.^2;  P2 = sum(s2sq(:)); % Мощность второй фигуры
PDIFF = P1 - P2;

% разносный сигнал
sDIF = s1 - s2;
% figure(3); imshow(sDIF)
AsDIF = abs(sDIF); SID = sum(AsDIF(:)); sDIFsq = sDIF.^2;

% figure(4); imshow(sDIFsq)
PDIF = sum(sDIFsq(:));

s12 = s1.*s2;
% figure(5); imshow(s12)

sd_noise = 500;
M1 = 100;

PETM = zeros(M1,1); PD1 = zeros(M1,1); PM1 = zeros(M1,1);
PD2 = zeros(M1,1); PM2 = zeros(M1,1); 

THR = (P1 - P2)/2;

R1=sd_noise*randn(200,200);
R2=sd_noise*randn(200,200);

S = bwconncomp(Im1);
Im1=zeros(S.ImageSize);
Im1(S.PixelIdxList{1})=255;
y1 = Im1 + R1; % Signal plus noise
y1=uint8(y1);

S = bwconncomp(Im2);
Im2=zeros(S.ImageSize);
Im2(S.PixelIdxList{1})=255;
y2 = Im2 + R2; % Signal plus noise
y2=uint8(y2);

cy1s12 = conv2(y1,sDIF,'same');  cy2s12 = conv2(y2,sDIF,'same');
x0 = 100; y0 = 100;

if (cy1s12(y0,x0) - THR)>0, PD1(1) = 1; end; % Cy1s1 = 1;
if (cy1s12(y0,x0) - THR)<0, PM1(1) = 1; end; % Cy1s2 = 1;
if (cy2s12(y0,x0) - THR)>0, PM2(1) = 1; end; % Cy2s1 = 1; 
if (cy2s12(y0,x0) - THR)<0, PD2(1) = 1; end; % Cy2s2 = 1; 

for m1 = 2:1:M1
 
disp(m1)
%%%% rand('state',0);
S = bwconncomp(Im1);
Im1=zeros(S.ImageSize);
Im1(S.PixelIdxList{1})=255;
y1 = Im1 + R1; % Signal plus noise
y1=uint8(y1);

S = bwconncomp(Im2);
Im2=zeros(S.ImageSize);
Im2(S.PixelIdxList{1})=255;
y2 = Im2 + R2; % Signal plus noise
y2=uint8(y2);

% y1 = s1;  y2 = s2;
% y1 = sd_noise*randn(m,n); % 
% y2 = sd_noise*randn(m,n); % 
cy1s12 = conv2(y1,sDIF,'same');  cy2s12 = conv2(y2,sDIF,'same');
Cy1s1 = 0; Cy1s2 = 0; Cy2s1 = 0; Cy2s2 = 0;

if (cy1s12(y0,x0) - THR)>0, Cy1s1 = 1; end; 
if (cy1s12(y0,x0) - THR)<0, Cy1s2 = 1; end; 
if (cy2s12(y0,x0) - THR)>0, Cy2s1 = 1; end;  
if (cy2s12(y0,x0) - THR)<0, Cy2s2 = 1; end; 

PD1(m1) = PD1(m1-1)*(m1-1)/m1 + Cy1s1/m1;
PD2(m1) = PD2(m1-1)*(m1-1)/m1 + Cy2s2/m1;
PM2(m1) = PM2(m1-1)*(m1-1)/m1 + Cy2s1/m1;
PM1(m1) = PM1(m1-1)*(m1-1)/m1 + Cy1s2/m1;
  
end; 

PD1M = PD1(M1); PD2M = PD2(M1); PM1M = PM1(M1); PM2M = PM2(M1);
PEM = (PM1M + PM2M)/2; PE1 = (1 - PD1M + PM1M)/2; PE2 = (1 - PD2M + PM2M)/2;
sd_noise = sd_noise
PNOISE = sd_noise*SID;
% q1 = P1/PNOISE
% q2 = P2/PNOISE
h = PDIF/(2*PNOISE); PET = 1 - normcdf(sqrt(h));

clc




