clear all;  close all;  clc;    T_max = 200;	T_step = 10;   
T=50; Kp = 0.5;   S_min = 50;    Ps_max = 50; razni=0.1;
I_src = imread('5DdGQ2nunu4.jpg');  
I_src=rgb2gray(I_src);
I_src=max(I_src(:))-I_src;

[I{1:T_max}] = deal([]);
[S{1:T_max}] = deal([]);
[P{1:T_max}] = deal([]);
colc=0;

%%
m=8;
mm=2;
N=40;
angle=0:1:360;
im1 = imread('D:\DiplomMAG\dataset\aroplane1\p (8).png'); imshow(im1);
im1=rgb2gray(im1);
im1=max(im1(:))-im1;
im1 = (im1> 150);
N=length(angle);

for i = 1:N
I1{i}=imrotate(im1,angle(i));
%
SS = bwconncomp(I1{i});
for g=1:length(SS.PixelIdxList)
    l(g)=length(SS.PixelIdxList{g});
end
[Contur,d]=max(l);
I1{i} = zeros(SS.ImageSize);
I1{i}(SS.PixelIdxList{d}) = 1;
Sss=bwconncomp(I1{i});
I = zeros(Sss.ImageSize);

% figure (1)
% imshow(I1{i})
s1 = regionprops(I1{i},'centroid');
g1=0;
g1 = ceil(s1.Centroid);
I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
ctr(i) =Ss.PixelIdxList{1};  % нахождения центра фигуры

Iz{i}=I1{i}+I;
figure (1)
imagesc(Iz{i})

SF1{i} = shapefactor_object1(I1{i},ctr); % вычисление факторов
if SF1{i}(4)==Inf
    SF1{i}(4)=100;
end
end

[SSF1]= shape(SF1,N);
t5=SSF1(:,m);t8=SSF1(:,mm);t2=SSF1(:,2);
t_O=[t8,t2];
m5=mean(t5);m8=mean(t8);m2=mean(t2);
c=[m5,m8];


%%
for T=1:T_step:T_max
    I_T = (I_src >= T);
    S{T} = bwconncomp(I_T);
    P{T} = regionprops(S{T},'Perimeter');
    colc=colc+1;
    
    I = zeros(S{T}.ImageSize);
    Istruct = zeros(S{T}.ImageSize);
    P_base = NaN(S{T}.NumObjects,1);
    SF8 = NaN(S{T}.NumObjects,1);
    raz = NaN(S{T}.NumObjects,1);
    
    disp(T);
    figure(T);
    I_P = zeros(S{T}.ImageSize);
    II=zeros(S{T}.ImageSize);
    I1 = zeros(S{T}.ImageSize);
    Ii{T} = zeros(S{T}.ImageSize);
    if T==1
    Istina=zeros(S{T}.ImageSize);
    end
    cnt_obj = 0;
    size_obj = [];
    for i=1:1:S{T}.NumObjects
        I1(S{T}.PixelIdxList{i})=1;
        s1 = regionprops(I1,'centroid');
        g1=0;
        g1 = ceil(s1.Centroid);
        Ii{T}(g1(2),g1(1))= 1;
        Ss=bwconncomp(Ii{T});
        ctr=Ss.PixelIdxList{1};
        for j=1:1:S{T}.NumObjects
           if sum(S{T}.PixelIdxList{j}==ctr) > 0
             break;
           end
        end
      A{T} = regionprops(S{T},'Area');
      MaxD{T} = regionprops(S{T},'MaxFeretProperties');
      SF8(T) = 4 * A{T}(i).Area / (MaxD{T}(i).MaxFeretDiameter.^2);
      raz(i)=abs(c-SF8(T));
%         P_base(i) = P{T}(i).Perimeter;
%         Ps_base(i) = P_base(i) * P_base(i) / 4 / 3.1415926 / length(S{T}.PixelIdxList{i});
       I1 = zeros(S{T}.ImageSize);
        if (length(S{T}.PixelIdxList{i}) > S_min)
            if (raz(i) > razni)
                I_P{T}(S{T}.PixelIdxList{i}) = T;
                
                cnt_obj = cnt_obj + 1; % создает отдельно обьекты на фото
                
                II=zeros(S{T}.ImageSize);
                II(S{T}.PixelIdxList{i}) = 1;
                I{colc}{cnt_obj}=II;
                s1 = regionprops(I{colc}{cnt_obj},'centroid');
                g1=0;
                g1 = ceil(s1.Centroid);
                ctr = 200*(g1(2)-1)+g1(1); % нахождения центра фигуры
                SF{colc}{cnt_obj}= shapefactor_object1(I{colc}{cnt_obj},ctr); % вычисление факторов
                if SF{colc}{cnt_obj}(4)==Inf
                SF{colc}{cnt_obj}(4)=100;
                end
                SF{colc}{cnt_obj}=(SF{colc}{cnt_obj})';
                k1(cnt_obj)=SF{colc}{cnt_obj}(m);k2(cnt_obj)=SF{colc}{cnt_obj}(mm);
                size_obj(cnt_obj) = length(S{T}.PixelIdxList{i});
            end
        end
    end
   k=[k1',k2'];
    
   dist=pdist2(k,c);
    
   n_obj(T)= cnt_obj ;
   Istina=Istina+I_P{T};
%    imshow(I_P);
%    colormap hot
%    colorbar('eastoutside')    
end


% %%
%  for i=1:cnt_obj
%  if dist(i)<0.5
%      Istruct=Istruct+I{2}{i};
%  end
%  end
%  figure(2);
%  imshow(Istruct);

%   for i=1:cnt_obj
%  if yfit(i)>0.5
%      Istruct=Istruct+I{2}{i};
%  end
%  end
%  figure(3);
%  imshow(Istruct);