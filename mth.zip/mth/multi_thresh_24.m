clear all;  close all;  clc;    T_max = 200;	T_step = 10;   
T=150;  S_min = 1000;    P_max = 10000; razni=0.1;

I_src = imread('5DdGQ2nunu4.jpg');  
I_src=rgb2gray(I_src);
I_src=max(I_src(:))-I_src;

Sf=open('SF_plane.mat');
SF_i=Sf.SSF1;
L_sit=Sf.LLD;

n1=1; n2=2;

two_train=[SF_i(:,n1) SF_i(:,n2)];


I_T = (I_src >= T);
S = bwconncomp(I_T);
P = regionprops(S,'Perimeter');

I = zeros(S.ImageSize);
Istruct = zeros(S.ImageSize);
P_base = NaN(S.NumObjects,1);

I_P = zeros(S.ImageSize);
II=zeros(S.ImageSize);
I1 = zeros(S.ImageSize);
Ii = zeros(S.ImageSize);
Istina=zeros(S.ImageSize);
cnt_obj = 0;
size_obj = [];
cS=0;cP=0;cSP=0;
    
for i=1:1:S.NumObjects
    i
       I1(S.PixelIdxList{i})=1;
       s1 = regionprops(I1,'centroid');
       g1=0;
       g1 = ceil(s1.Centroid);
       Ii(g1(2),g1(1))= 1;
       Ss=bwconncomp(Ii);
       ctr=Ss.PixelIdxList{1};
       SF = shapefactor_object1(I1,ctr);
       SF=SF';
       
       Sf1(i)=SF(:,n1);
       Sf2(i)=SF(:,n2);
       
       Sf_s=[SF(:,n1) SF(:,n2)];
       
       
       P = regionprops(I1,'Perimeter');
       P=P.Perimeter;
       if length(S.PixelIdxList{i}) > S_min
          cS=cS+1;
       end
       if P<P_max
          cP=cP+1;
       end
       
        if (length(S.PixelIdxList{i}) > S_min) && P<P_max
            cSP=cSP+1;
            cnt_obj=cnt_obj+1;
            [LL_d{i}] = dist_round(I1);
            
            R(cnt_obj)=corr2(LL_d{i},L_sit);
       
            Dis{cnt_obj}=pdist2(Sf_s,two_train);
            Dis_m(cnt_obj)=mean(Dis{cnt_obj});
            
            z(i)=0;
         
                if Dis_m(cnt_obj)<razni | R(cnt_obj)>0.6
                z(i)=1;
                I_P(S.PixelIdxList{i})=length(S.PixelIdxList{i});
                end
        end
        
        I1 = zeros(S.ImageSize);
end
  
Istina=I_P>0;

figure (11)
imagesc (I_P)

S=bwconncomp(Istina);
Nobj=S.NumObjects;
B=struct2cell(regionprops(S,'BoundingBox'));
s=size(B);
Naiming=['Количество найденных Boeing-737: ', num2str(Nobj)];

I_src = imread('5DdGQ2nunu4.jpg');  
figure (1)
imshow(I_src)
title (Naiming)

hold on
for i=1:s(2)
rectangle('Position',ceil(B{i}),'EdgeColor','b')
text((ceil(B{i}(1))),(ceil(B{i}(2)-10)),'Boeing-737');
end

for i=1:length(LL_d)
   figure(2)
  hold on
  grid on
   plot(LL_d{i},'b')
   if z(i)==1
       plot(LL_d{i},'g')
   end
   xlim([0,361]);
   xlabel('Угол поворота');ylabel('Нормированная дистанция');
end
plot(L_sit,'Color','r','LineWidth',2)


figure (3)
hold on
grid on
plot (Sf1, Sf2, '.','Color','b')
plot (SF_i(:,n1), SF_i(:,n2), '.','Color','r')
xlabel('Соотношение площади');ylabel('Соотношение диаметров Фере');
