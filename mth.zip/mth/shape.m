function [SSF]...
    = shape(SF,N)
for i=1:N
    SF1(i)=SF{i}(1); SF2(i)=SF{i}(2); SF3(i)=SF{i}(3);
    SF4(i)=SF{i}(4); SF5(i)=SF{i}(5); SF6(i)=SF{i}(6);
    SF7(i)=SF{i}(7); SF8(i)=SF{i}(8); SF9(i)=SF{i}(9);
    SF10(i)=SF{i}(10);
end
SF1=SF1'; SF2=SF2'; SF3=SF3';
SF4=SF4'; SF5=SF5'; SF6=SF6';
SF7=SF7'; SF8=SF8'; SF9=SF9';
SF10=SF10';
SSF=[SF1, SF2, SF3, SF4, SF5, SF6, SF7, SF8, SF9, SF10];
end

