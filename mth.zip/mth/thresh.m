clear all;  close all;  clc;    T_max = 255;	T_step = 1;   
T=50; Kp = 0.5;   S_min = 100; razni=0.2;
I_src = imread('5DdGQ2nunu4.jpg');  
I_src=rgb2gray(I_src);
I_src=max(I_src(:))-I_src;

[I{1:T_max}] = deal([]);
[S{1:T_max}] = deal([]);
[P{1:T_max}] = deal([]);

m=8;
mm=2;
N=40;
angle=0:1:360;
im1 = imread('D:\DiplomMAG\dataset\aroplane1\p (8).png'); imshow(im1);
im1=rgb2gray(im1);
im1=max(im1(:))-im1;
im1 = (im1> 150);
N=length(angle);

for i = 1:N
I1{i}=imrotate(im1,angle(i));
%
SS = bwconncomp(I1{i});
for g=1:length(SS.PixelIdxList)
    l(g)=length(SS.PixelIdxList{g});
end

[Contur,d]=max(l);
I1{i} = zeros(SS.ImageSize);
I1{i}(SS.PixelIdxList{d}) = 1;
Sss=bwconncomp(I1{i});
I = zeros(Sss.ImageSize);

P_mp=regionprops(Sss,'Perimeter');
P_max(i)=P_mp.Perimeter;

A_mp=regionprops(Sss,'Area');
A_min(i)=A_mp.Area;

s1 = regionprops(I1{i},'centroid');
g1=0;
g1 = ceil(s1.Centroid);
I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
ctr(i) =Ss.PixelIdxList{1};  % нахождения центра фигуры

Iz{i}=I1{i}+I;
figure (1)
imagesc(Iz{i})

SF1{i} = shapefactor_object1(I1{i},ctr); % вычисление факторов
if SF1{i}(4)==Inf
    SF1{i}(4)=100;
end
end
[SSF1]= shape(SF1,N);
t6=SSF1(:,6); t8=SSF1(:,8);t2=SSF1(:,2);

P_max=max(P_max);
A_min=min(A_min);

m6=mean(t6);m8=mean(t8);m2=mean(t2);
coef1=[m2 m8];
coef2=[m2 m6];

for T=1:T_step:T_max
    I_T = (I_src >= T);
    S{T} = bwconncomp(I_T);
    
    I = zeros(S{T}.ImageSize);
    Istruct = zeros(S{T}.ImageSize);
    raz{T} = NaN(S{T}.NumObjects,1);
    
    disp(T);
    I_P{T} = zeros(S{T}.ImageSize);
    II=zeros(S{T}.ImageSize);
    I1 = zeros(S{T}.ImageSize);
    Ii{T} = zeros(S{T}.ImageSize);
    if T==1
    Istina=zeros(S{T}.ImageSize);
    I_z=zeros(S{T}.ImageSize);
    end
    cnt_obj = 0;
    size_obj = [];
    
    
    for i=1:S{T}.NumObjects
        if (length(S{T}.PixelIdxList{i}) > A_min)
        I1(S{T}.PixelIdxList{i})=1;
        Sis=bwconncomp(I1);
        s1 = regionprops(I1,'centroid');
        g1=0;
        g1 = ceil(s1.Centroid);
        Ii{T}(g1(2),g1(1))= 1;
        Ss=bwconncomp(Ii{T});
        ctr=Ss.PixelIdxList{1};
        
        A = regionprops(Sis,'Area');
        MaxD = regionprops(Sis,'MaxFeretProperties');
        MinD = regionprops(Sis,'MinFeretProperties');
        E = regionprops(Sis,'Eccentricity');
        P = regionprops(Sis,'Perimeter');
        
        
        for j=1:Sis.NumObjects
        if sum(Sis.PixelIdxList{j}==ctr) > 0
        break;
        end
        end
     
      SF8 = 4 * A(j).Area / (MaxD(j).MaxFeretDiameter.^2);
      SF2 = MaxD(j).MaxFeretDiameter / MinD(j).MinFeretDiameter;
      SF6 = E(j).Eccentricity;
      P_s=P.Perimeter;
      t_n1{T}{i}=[SF2 SF8];
      t_n2{T}{i}=[SF2 SF6];
      raz1{T}(i)=pdist2(t_n1{T}{i},coef1); 
      raz2{T}(i)=pdist2(t_n2{T}{i},coef2);
      I1 = zeros(S{T}.ImageSize);
      
        if (raz1{T}(i) < razni)
        if (raz2{T}(i) < razni)
        if (P_s < P_max)
                I_P{T}(S{T}.PixelIdxList{i}) = T; % попробовать заменить Istina на данную переменную
                Istina(S{T}.PixelIdxList{i})=T;
                I_z(S{T}.PixelIdxList{i}) = 1;
        end
        end
        end
        end
        end
end

figure(2)
imagesc(Istina)
colorbar

I_z =medfilt2(I_z, [3,3],'symmetric');
Sis=bwconncomp(I_z);
Num_obj=Sis.NumObjects
