function [LL] = dist_round(Im)

S = bwconncomp(Im);
B=regionprops(S,'BoundingBox');
imagesc(Im);
I_crop = imcrop(Im,[B.BoundingBox(1) B.BoundingBox(2)...
    B.BoundingBox(3) B.BoundingBox(4)]);

angle=0:1:360;
N=length(angle);

for a = 1:N
    Il=imrotate(I_crop,angle(a));
    S = bwconncomp(Il);
    P_l=S.PixelIdxList;
    for z=1:S.NumObjects
        L(z)=length(P_l{z});
    end
    [~,M]=max(L);
    L=0;
    B=struct2cell(regionprops(S,'BoundingBox'));
    I{a}= imcrop(Il,[B{M}(1) B{M}(2) B{M}(3) B{M}(4)]);
    Sm=size( I{a});
    Sk(a)=Sm(2);
end

[~,al]=min(Sk);
I_crop=I{al};

[R,d]=size(I_crop);
D=d*10;
I_z=zeros(R,D/2);
I_crop=[I_z I_crop I_z];
Ik=[I_z I_crop];

Ss = bwconncomp(Ik);
c=regionprops(Ss,'Centroid');
r=ceil(R/2);
Ik(r,1)=255;

for a = 1:N
    I=imrotate(I_crop,angle(a),'crop');
    S = bwconncomp(I);
    B=regionprops(S,'BoundingBox');

    [R,L]=size(I);
    I_z=zeros(R,D);
    I_d=[I_z I];
    [R,L]=size(I_d);
    r=round(R/2);
    c=1;
    cort=c;
    I_d(r,1)=1;
    
    while I_d(r,cort+1)==0
          cort=cort+1;
    end
    
    I_d(r,cort)=2;
    distanse{a}=c:cort;
    Ll(a)=length(distanse{a});
    for i=1:Ll(a)
    I_d(r,distanse{a}(i))=2;
    end
%     figure (1)
% imagesc(I_d);
end

[p,s]=max(Ll);

Dmin=Ll(1:s-1); Dmax=Ll(s:361);

 LL=Ll/p;
 for i = 2:1:length(L)-2
     LL(i)=(L(i)+L(i-1)+L(i+1))./3;
 end
 
end

