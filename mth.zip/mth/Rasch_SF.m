clear all;  close all;  clc;    T_max = 200;	T_step = 10;   
T=50; Kp = 0.5;   S_min = 50;    Ps_max = 50; razni=0.1;
I_src = imread('5DdGQ2nunu4.jpg');  
I_src=rgb2gray(I_src);
I_src=max(I_src(:))-I_src;

[I{1:T_max}] = deal([]);
[S{1:T_max}] = deal([]);
[P{1:T_max}] = deal([]);
colc=0;

%%
m=8;
mm=2;
N=40;
angle=0:1:360;
im1 = imread('D:\DiplomMAG\dataset\aroplane1\p (8).png'); imshow(im1);
im1=rgb2gray(im1);
im1=max(im1(:))-im1;
im1 = (im1> 150);
N=length(angle);

for i = 1:N
I1{i}=imrotate(im1,angle(i));
%
SS = bwconncomp(I1{i});
for g=1:length(SS.PixelIdxList)
    l(g)=length(SS.PixelIdxList{g});
end
[Contur,d]=max(l);
I1{i} = zeros(SS.ImageSize);
I1{i}(SS.PixelIdxList{d}) = 1;

if i==1
    [LLC] = razvert(I1{i});
    [LLD] = dist_round(I1{i});
end

Sss=bwconncomp(I1{i});
I = zeros(Sss.ImageSize);

% figure (1)
% imshow(I1{i})
s1 = regionprops(I1{i},'centroid');
g1=0;
g1 = ceil(s1.Centroid);
I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
ctr(i) =Ss.PixelIdxList{1};  % нахождения центра фигуры

Iz{i}=I1{i}+I;
figure (1)
imagesc(Iz{i})

SF1{i} = shapefactor_object1(I1{i},ctr); % вычисление факторов
if SF1{i}(4)==Inf
    SF1{i}(4)=100;
end
end

[SSF1]= shape(SF1,N);