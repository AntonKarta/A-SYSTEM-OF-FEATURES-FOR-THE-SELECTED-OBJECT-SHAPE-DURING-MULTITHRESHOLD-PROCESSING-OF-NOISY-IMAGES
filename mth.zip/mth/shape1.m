function [SSF]...
    = shape1(SFn,N)
for i=1:N
    SFn1(i)=SFn{i}(1); SFn2(i)=SFn{i}(2); SF3(i)=SFn{i}(3);
    SFn4(i)=SFn{i}(4); SFn5(i)=SFn{i}(5); SFn6(i)=SFn{i}(6);
    SFn7(i)=SFn{i}(7); SFn8(i)=SFn{i}(8); SFn9(i)=SFn{i}(9);
    SFn10(i)=SFn{i}(10);
end
% SF1=SF1'; SF2=SF2'; SF3=SF3';
% SF4=SF4'; SF5=SF5'; SF6=SF6';
% SF7=SF7'; SF8=SF8'; SF9=SF9';
% SF10=SF10';
SSF=[SFn1', SFn2', SFn3', SFn4', SFn5', SFn6', SFn7', SFn8', SFn9', SFn10'];
end

