clear all;  close all;  clc;    T_max = 120;	T_step = 10;   
T=50; Kp = 0.5;   S_min = 50;    Ps_max = 50;
I_src = imread('5DdGQ2nunu4.jpg');  
I_src=rgb2gray(I_src);
I_src=max(I_src(:))-I_src;

[I{1:T_max}] = deal([]);
[S{1:T_max}] = deal([]);
[P{1:T_max}] = deal([]);
colc=0;

%%
m=2;
mm=8;
N=40;
for i = 1:N
Iname1=['D:\DiplomMAG\dataset\aroplane1\p (' num2str(i) ').png']; 
I1{i}=imread(Iname1);% запись изображений
I1{i}=rgb2gray(I1{i});
I1{i}=max(I1{i}(:))-I1{i};
I1{i} = (I1{i} > 130);
%
SS = bwconncomp(I1{i});
for g=1:length(SS.PixelIdxList)
    l(g)=length(SS.PixelIdxList{g});
end
[Contur,d]=max(l);
I1{i} = zeros(SS.ImageSize);
I1{i}(SS.PixelIdxList{d}) = 1;

s1 = regionprops(I1{i},'centroid');
g1=0;
g1 = ceil(s1.Centroid);
ctr = 200*(g1(2)-1)+g1(1); % нахождения центра фигуры

SF1{i} = shapefactor_object1(I1{i},ctr); % вычисление факторов
if SF1{i}(4)==Inf
    SF1{i}(4)=100;
end
end
[SSF1]= shape(SF1,N);
t5=SSF1(:,m);t8=SSF1(:,mm);t2=SSF1(:,2);
t_O=[t8,t2];
m5=mean(t5);m8=mean(t8);m2=mean(t2);
c=[m5,m8];

%%
for T=110:T_step:T_max
    I_T = (I_src >= T);
    S{T} = bwconncomp(I_T);
    P{T} = regionprops(S{T},'Perimeter');
    colc=colc+1;
    
    I{T} = zeros(S{T}.ImageSize);
    Istruct = zeros(S{T}.ImageSize);
    P_base = NaN(S{T}.NumObjects,1);
    Ps_base = NaN(S{T}.NumObjects,1);
    
    disp(T);
    figure(T);
    I_P = zeros(S{T}.ImageSize);
    II=zeros(S{T}.ImageSize);
    
    cnt_obj = 0;
    size_obj = [];
    for i=1:1:S{T}.NumObjects
        P_base(i) = P{T}(i).Perimeter;
        Ps_base(i) = P_base(i) * P_base(i) / 4 / 3.1415926 / length(S{T}.PixelIdxList{i});
        
        if (length(S{T}.PixelIdxList{i}) > S_min)
            if (Ps_base(i) < Ps_max)
                I_P(S{T}.PixelIdxList{i}) = Ps_base(i);
                
                cnt_obj = cnt_obj + 1; % создает отдельно обьекты на фото
                
                II=zeros(S{T}.ImageSize);
                II(S{T}.PixelIdxList{i}) = 1;
                I{colc}{cnt_obj}=II;
                s1 = regionprops(I{colc}{cnt_obj},'centroid');
                g1=0;
                g1 = ceil(s1.Centroid);
                ctr = 200*(g1(2)-1)+g1(1); % нахождения центра фигуры
                SF{colc}{cnt_obj}= shapefactor_object1(I{colc}{cnt_obj},ctr); % вычисление факторов
                if SF{colc}{cnt_obj}(4)==Inf
                SF{colc}{cnt_obj}(4)=100;
                end
                SF{colc}{cnt_obj}=(SF{colc}{cnt_obj})';
                k1(cnt_obj)=SF{colc}{cnt_obj}(m);k2(cnt_obj)=SF{colc}{cnt_obj}(mm);
                size_obj(cnt_obj) = length(S{T}.PixelIdxList{i});
            end
        end
    end
   k=[k1',k2'];
    
   dist=pdist2(k,c);
    
   n_obj(T)= cnt_obj ;
   imshow(I_P);
%    colormap hot
%    colorbar('eastoutside')    
end


%%
 for i=1:cnt_obj
 if dist(i)<0.1
     Istruct=Istruct+I{2}{i};
 end
 end
 figure(1);
 imshow(Istruct);
