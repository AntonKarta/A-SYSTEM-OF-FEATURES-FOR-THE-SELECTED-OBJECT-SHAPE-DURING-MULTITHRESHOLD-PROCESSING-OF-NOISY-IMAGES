clear all;  close all
im1 = imread('D:\DiplomMAG\dataset\aroplane1\p (8).png'); 
 im1=rgb2gray(im1);
 im1=max(im1(:))-im1;
I_T = (im1 >= 150);
S=bwconncomp(I_T);
m=S.PixelIdxList;
I1 = zeros(S.ImageSize);
I = zeros(S.ImageSize);
for i=1:S.NumObjects
 I1(S.PixelIdxList{i})=1;
% % Z=ceil(length(L{i})/2);
% C(i)=L{i}(Z);
% I(C(i)) = 1;
s1 = regionprops(I1,'centroid');
g1=0;
g1 = ceil(s1.Centroid);
I(g1(2),g1(1))= 1;
Ss=bwconncomp(I);
center(i)=Ss.PixelIdxList{1};
I(center) = 1;
I1 = zeros(S.ImageSize);
end

II=I+I_T;

imagesc (II)
colormap hot
colorbar('eastoutside') 